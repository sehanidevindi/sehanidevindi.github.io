<?php
include("includes/header.php");

?>
	
	<div class="content_wrapper">
	<nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top" style="z-index:3;width:250px;float:left;"  id="mySidebar">
	<div class="w3-container w3-display-container w3-padding-16">
    <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
	</div>
		<div id="side-bar" style="height:auto">
			<div class = "header_logo">
				<a href ="index.php">
				<img id ="logo" src ="images/logo1.jpg" width="150px" height="120px"/>	
				</a>
			</div><!--/.header_logo-->
			<div id="side-bar_title" style="font-size:25px;font-family:serif;padding:10px;text-align:left"><b>Categories</b></div>
			<ul id="cats" style="text-align:left;color:black">
				<?php
				getCats();
				?>
			</ul>
			
			<div id="side-bar_title" style="font-size:25px;font-family:serif;padding:10px;text-align:left"><b>Brands</b></div>
			<ul id="cats" style="text-align:left">
				<?php
				getBrands();
				?>
		
			</ul><!--/#sidebar -->
		
	</nav>	
		
		
		
			<div class="w3-main" style="margin-left:200px;margin-right:5px">
			
			<div id="products_box" class="w3-row w3-grayscale-min" >
			
				<?php
					$get_pro = " select * from products ";
					$run_pro = mysqli_query($con, $get_pro);
					while($row_pro = mysqli_fetch_array($run_pro)){
						$pro_id = $row_pro['product_id'];
						$pro_cat = $row_pro['product_cat'];
						$pro_brand = $row_pro['product_brand'];
						$pro_title = $row_pro['product_title'];
						$pro_price = $row_pro['product_price'];
						$pro_image = $row_pro['product_image'];
						

						
						
						echo "
							
							<div class ='w3-col l3 s6'>
								<div class='w3-container'>
								   <div class='w3-display-container' style='padding:15px;float:left'>
										<img src = 'admin_area/product_images/$pro_image' width='160px' height='220px'style='border:none'/>
										<div class='w3-display-middle w3-display-hover'>
											<div class='buttons'>
											<a href='index.php?add_cart=$pro_id'><button class='w3-button w3-black' >Buy now <i class='fa fa-shopping-cart'></i></button></a>
											</div>
										</div>
										<p>$pro_title </br><b> Price: Rs. $pro_price </b></p>
									</div>
								</div>
								
							</div>
						";
					 }
				?>
				<?php
					get_pro_by_cat_id();
				?>
				
				<?php
					get_pro_by_brand_id();
				?>
				
				
			</div><!-- /#products_box-->
		</div>
		
	</div><!-- /.content_wrapper-->
	
	<?php include ('includes/footer.php');?>
