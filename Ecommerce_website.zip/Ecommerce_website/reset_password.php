<?php
include("includes/header.php");

?>

	<div class="content_wrapper">
		
		
		<div class ="register_box" style ="width:100%;float:left;padding:15px;background:white">

		<form method ="post" action ="" enctype= "multipart/form-data">

			<table align="left" width ="70%">
				<tr align="left">
					<td colspan ="4">
					<h2 style="background:rgb(66, 245, 239)">Reset Password.</h2><br/>
			
				<tr>
					
					<td colspan="3"><input type ="text" name ="email" placeholder ="Your email" required style="width:60%;padding:3px ;margin:5px 0"/></td>
				</tr>
	
		<tr align="left">
		 <td colspan="6">
			<input type="submit" name="reset" value ="Send Reset Email" style="padding:10px 15px;background:rgba(28,130,199,0.9);border:0.01px solid rgba(28,130,199,0.8);color:white" />
		 </td>
		</tr>
		
	</table>


</form>
</div>


	
	
	</div><!-- /.content_wrapper-->
	
	<?php include ('includes/footer.php');?>