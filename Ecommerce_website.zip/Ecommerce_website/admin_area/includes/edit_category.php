
	<style>
	.content{
		width:75%;
		float:left;
	}

	.content_box{
		padding:15px;
	}
	
	.form_box input[type=text]{
		padding:3px 10px;
		margin:5px 0;
	}
	.form_box select{
		width:40%;
		padding:3px 10px;
		margin:5px 0;
	}
	.form_box input[type=file]{
		margin:5px 0;
	}
	.form_box textarea{
		width:80%;
		
	}
	.form_box input[type=submit]{
		padding:10px 15px;
		background:rgba(28,130,199,0.9);
		border:0.01px solid rgba(28,130,199,0.8);
		color:white;
	}
	</style>
	
	
	
	<?php
		$edit_cat= mysqli_query($con,"select * from categories where cat_id='$_GET[cat_id]'");
		
		$fetch_cat =mysqli_fetch_array($edit_cat);
	
	?>
	<div class ="form_box">
	
	<form action="" method="post" enctype="multipart/form-data">
		<table align="center" width="100%">
			<tr>
				<td colspan="7">
				<h2>Edit Category</h2>
				<div class="border_bottom" style="border-bottom:0.01px solid rgba(0,0,0,0.2);margin:10px 0">
				
				</div><!-- /.border_bottom -->
				</td>
			</tr>
			
			<tr>
				<td><b>Edit Category:</b></td>
				<td><input type="text" name="product_cat" size="60"  value="<?php echo $fetch_cat['cat_title']; ?>" required /></td>
			</tr>
		
		
			<tr>
			<td></td>
			<td colspan="7"><input type="submit" name="edit_cat" value="Save"/></td>
			</tr>
		</table>
	</form>

	</div><!-- /.form_box-->

<?php
if(isset($_POST['edit_cat'])){
	
	$cat_title=mysqli_real_escape_string($con,$_POST['product_cat']);
	
	$edit_cat = mysqli_query($con,"update categories set cat_title='$cat_title' where cat_id='$_GET[cat_id]' ");
	
	if($edit_cat){
	echo "<script>alert('Product category was updated successfullly!')</script>";
	
	echo "<script>window.open(window.location.href,'_self')</script>";
	}
	
}
?>

