
	<style>
	.content{
		width:75%;
		float:left;
	}

	.content_box{
		padding:15px;
	}
	
	.form_box input[type=text]{
		padding:3px 10px;
		margin:5px 0;
	}
	.form_box select{
		width:40%;
		padding:3px 10px;
		margin:5px 0;
	}
	.form_box input[type=file]{
		margin:5px 0;
	}
	.form_box textarea{
		width:80%;
		
	}
	.form_box input[type=submit]{
		padding:10px 15px;
		background:rgba(28,130,199,0.9);
		border:0.01px solid rgba(28,130,199,0.8);
		color:white;
	}
	</style>
	<div class ="form_box">
	
	<form action="" method="post" enctype="multipart/form-data">
		<table align="center" width="100%">
			<tr>
				<td colspan="7">
				<h2>Add Category</h2>
				<div class="border_bottom" style="border-bottom:0.01px solid rgba(0,0,0,0.2);margin:10px 0">
				
				</div><!-- /.border_bottom -->
				</td>
			</tr>
			
			<tr>
				<td><b>Add New Category:</b></td>
				<td><input type="text" name="product_cat" size="60" required/></td>
			</tr>
		
		
			<tr>
			<td></td>
			<td colspan="7"><input type="submit" name="insert_cat" value="Add Category"/></td>
			</tr>
		</table>
	</form>

	</div><!-- /.form_box-->

<?php
if(isset($_POST['insert_cat'])){
	
	$product_cat=mysqli_real_escape_string($con,$_POST['product_cat']);
	
	$insert_cat = mysqli_query($con,"insert into categories (cat_title) values ('$product_cat') ");
	
	if($insert_cat){
	echo "<script>alert('Product category has Been inserted successfullly!')</script>";
	
	echo "<script>window.open(window.location.href,'_self')</script>";
	}
	
}
?>

