function payment(){
		global $con;
		if(isset($_GET['pay'])){
		$total = 0;
		$ip =get_ip();
		$run_cart = mysqli_query($con, "select * from cart where ip_address='$ip' ");
		while($fetch_cart = mysqli_fetch_array($run_cart)){
			$product_id = $fetch_cart['product_id'];
			$result_product = mysqli_query($con ,"select * from products where product_id ='$product_id' ");
			while($fetch_product = mysqli_fetch_array($result_product)){
				$product_price = array($fetch_product['product_price']);
				$product_title = $fetch_product['product_title'];
				$product_image = $fetch_product['product_image'];
				$sing_price = $fetch_product['product_price'];
				$values = array_sum($product_price);
		
		$run_insert_payment=mysqli_query($con, "INSERT INTO payment(name,total_price,product_title) VALUES('$ip','$values','$product_title')");
			}
			
			
				payment();