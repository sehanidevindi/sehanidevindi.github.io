<?php
include("includes/header.php");

?>


	<?php if(!isset($_GET['action'])){?>
	<div class="content_wrapper" style="100%">
		<nav class="w3-sidebar w3-bar-block  w3-collapse w3-top" style="z-index:3;width:250px;float:left;" id="mySidebar">
		<div class="w3-container w3-display-container w3-padding-16">
			<i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
		</div>
	
		<div id="side-bar" style="height:auto">
			<div class = "header_logo">
				<a href ="index.php">
				<img id ="logo" src ="images/logo1.jpg" width="150px" height="120px"/>	
				</a>
			</div><!--/.header_logo-->
			<div id="side-bar_title" style="font-size:25px;font-family:serif;padding:10px;text-align:left"><b>Categories</b></div>
			<ul id="cats" style="text-align:left;color:black">
				<?php
				getCats();
				?>
			</ul>
			
			<div id="side-bar_title" style="font-size:25px;font-family:serif;padding:10px;text-align:left"><b>Brands</b></div>
			<ul id="cats" style="text-align:left">
				<?php
				getBrands();
				?>
		
			</ul>
			
		</div><!--/#sidebar -->
		</nav>
		
		<div class="w3-main" style="margin-left:200px;margin-right:5px">
		 <div class="w3-display-container w3-container" style="max-width:1000px">
		<div class="w3-content w3-section" style="max-width:1000px">
			<img class="mySlides w3-opacity" src="images/slideimg1.jpg" style="width:100%">
			<img class="mySlides w3-opacity" src="images/slideimg5.jpg" style="width:100%">
			<img class="mySlides w3-opacity" src="images/slideimg8.jpg" style="width:100%">
			<div class="w3-display-topleft w3-text-black" style="padding:24px 100px">
				<h1 class="w3-jumbo w3-hide-small">New arrivals</h1>
				<h1 class="w3-hide-large w3-hide-medium">New arrivals</h1>
				<h1 class="w3-hide-small">COLLECTION 2021</h1></br>
				<p><a href="#products_box" class="w3-button w3-black w3-padding-large w3-large">SHOP NOW</a></p>
			</div>
			</div>
		
	

<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>

			
			<?php cart();?>
		
			<div id="products_box" class="w3-row w3-grayscale-min" style="max-width:1000px">
				
				<?php getPro(); ?>
				<?php get_pro_by_cat_id();?>
				<?php get_pro_by_brand_id(); ?>
				
			</div><!-- /#products_box-->
		
		<?php }else{ ?>
		<?php include('login.php');
		} ?>
		
		</div>
	</div><!-- /.content_wrapper-->
	
	<?php include ('includes/footer.php');?>
