
<html>
<head>
<style>
	
	.item{
		width:100%;
		float:left;
		padding:10px;
	}
	.payment{
		margin-left:75px;
		width:500px;
		float:right;
		padding:25px;
		
	}
	

  
</style>
</head>
<body>
	<div class="bg-img" style= "background-image: url('images/slideimg9.jpg');min-height: 380px;background-position: center;background-repeat: no-repeat;background-size:cover;position: relative; margin-top:20px">
 
	<form method="post">   
		<input type="hidden" name="merchant_id" value="1217315">    <!-- Merchant ID -->
		<input type="hidden" name="return_url" value="http://sample.com/return">
		<input type="hidden" name="cancel_url" value="http://sample.com/cancel">
		<input type="hidden" name="notify_url" value="notifyurl.php">  
		<br><br>
	
		
		<div class="payment" style="background:rgba(191, 187, 187, 0.5)">
			<br><b style ="background-color:white;text-align:center;padding:15px 80px;font-size:18px">Total Price: <?php total_price();?></b><br><br><br>
			<b style="color:navy;font-size:25px">Confirm Your Payment</b><br><br>
			<a href="https://sandbox.payhere.lk/pay/checkout" name="pay"><img src="https://www.payhere.lk/downloads/images/pay_with_payhere_light.png" alt="Pay with PayHere" width="180"/></a><br><br> <br>	
		</div>
			
			
	</form> 
	</div>
	<div class=" w3-display-container"style="float:right;margin-right:250px">
		<div class="w3-display-topleft w3-container w3-xlarge">
			<p><button  onclick="document.getElementById('menu').style.display='block'" class="w3-button w3-black">Chech your Item<i class="fa fa-shopping-cart"></i></button></p>
		</div>
	</div>

<!-- Menu Modal -->
	<div id="menu" class="w3-modal">
		<div class="w3-modal-content w3-animate-zoom">
			<div class="w3-container w3-grey w3-display-container">
				<span onclick="document.getElementById('menu').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
			</div>
			<div class="w3-container">
				<div class="item">
					<b style="color:navy">Your Item(<?php total_items(); ?>)</b><br><br>
					<?php	
						$total = 0;
						$ip =get_ip();
						$run_cart = mysqli_query($con, "select * from cart where ip_address='$ip' ");
						while($fetch_cart = mysqli_fetch_array($run_cart)){
							$product_id = $fetch_cart['product_id'];
							$result_product = mysqli_query($con ,"select * from products where product_id ='$product_id' ");
							while($fetch_product = mysqli_fetch_array($result_product)){
								$product_price = array($fetch_product['product_price']);
								$product_title = $fetch_product['product_title'];
								$product_image = $fetch_product['product_image'];
								$sing_price = $fetch_product['product_price'];
								$values = array_sum($product_price);
								

				
				
					echo "
							
							<div class ='w3-col l3 s6'>
								<div class='w3-container'>
								   <div class='w3-display-container' style='padding:15px;float:left'>
										<img src='admin_area/product_images/$product_image' style='width:90px;height:130px'/><br>
										<p>$product_title </br><b> Price: Rs. $sing_price </b></p>
									</div>
								</div>
								
							</div>
						";
					
			
					 } }//End While ?>
				</div>
			</div>
		</div>
</div>
</body>
</html>
	
