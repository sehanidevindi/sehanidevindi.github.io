
<div class="bg-img" style= "background-image: url('images/slideimg9.jpg');min-height: 380px;background-position: center;background-repeat: no-repeat;background-size:cover;position: relative; margin-top:20px">
  <form method="post" action="" class="container-login" style="position: absolute;right: 0;margin: 20px;max-width: 300px;padding: 16px;background-color: white">
    <h5 style="font-family:serif;font-size:30px"><b>Login<b></h5>
	<span style="font-family:calbiri;font-size:15px">
				Don't have an account?<a href ="register.php" style="color:rgb(176, 66, 245);font-family:serif;font-size:15px">Register Here</a>
	</span>
    <label for="email" style="font-family:serif;font-size:20px"><b>Email</b></label>
    <input type="text" style=" width: 100%;padding: 15px;margin: 5px 0 22px 0;border: none;background: #f1f1f1" placeholder="Enter Email" name="email" required>

    <label for="psw" style="font-family:serif;font-size:20px"><b>Password</b></label>
    <input type="password" name ="password" style=" width: 100%;padding: 15px;margin: 5px 0 22px 0;border: none;background: #f1f1f1" placeholder="Enter Password"  required>

    <input type="submit" name="login" value ="Login" style=" background-color: #04AA6D;color: white;padding: 16px 20px;border: none;cursor: pointer;width: 100%;opacity: 0.9;">
  </form>
</div>




<?php
if(isset($_POST['login'])){
	$email =trim($_POST['email']);
	$password = trim($_POST['password']);
	$password = md5($password);
	
	
	$run_login = mysqli_query($con, "select * from users where password='$password' AND email='$email'");
	$check_login = mysqli_num_rows($run_login);
	
	$row_login = mysqli_fetch_array($run_login);
	
	if($check_login==0){
		echo "<script>alert('password or email is incorrect, please try again!')</script>";
		exit();
	}
	$ip = get_ip();
	$run_cart=mysqli_query($con,"select * from cart where ip_address='$ip' ");
	
	$check_cart = mysqli_num_rows($run_cart);
	
	if($check_login>0 AND $check_cart==0){
		
		 $_SESSION['user_id'] = $row_login['id'];
		
		 $_SESSION['role'] = $row_login['role'];
		
		$_SESSION['email']= $email;
		echo "<script>alert('You have logged in successfully !')</script>";
		echo "<script>window.open('customer/my_account.php','_self')</script>";
		
	}else{
		
		 $_SESSION['user_id'] = $row_login['id'];
		
		 $_SESSION['role'] = $row_login['role'];
		
		$_SESSION['email'] = $email;
		echo "<script>alert('You have logged in successfully !')</script>";
		echo "<script>window.open('checkout.php','_self')</script>";
	}
}

 ?>