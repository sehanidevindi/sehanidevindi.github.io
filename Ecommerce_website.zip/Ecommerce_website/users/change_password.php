<?php
	$select_user = mysqli_query($con,"select * from users where id='$_SESSION[user_id]' ");
	
	$fetch_user = mysqli_fetch_array($select_user);
?>
		<div class ="register_box" style ="width:100%;float:left;padding:15px;background:white">

		<form method ="post" action ="" enctype= "multipart/form-data">

			<table align="left" width ="70%">
				<tr align="left">
					<td colspan ="4">
					<h2 style="background:rgb(66, 245, 239)">Change Password.</h2><br/>
					</td>
				</tr>
				
				<tr>
					<td width="15%"><b>Current Password:</b></td>
					<td colspan="3"><input type ="password" name ="current_password" id="password_confirm1" required placeholder ="Current Password" style="width:60%;padding:3px;margin:5px 0"/></td>
				</tr>
				
				<tr>
					<td width="15%"><b>New Password:</b></td>
					<td colspan="3"><input type ="password" name ="new_password" id="password_confirm1" required placeholder ="New Password" style="width:60%;padding:3px;margin:5px 0"/></td>
				</tr>
		
				<tr>
					<td width="35%"><b>Re-Type Password:</b></td>
					<td colspan="3"><input type ="password" name ="confirm_new_password" id="password_confirm2" required placeholder ="Re-Type New Password" style="width:60%;padding:3px;margin:5px 0"/>
					 <p id = "status_for_confirm_password"></p><!-- showing validate password here -->
					</td>
				</tr>
	
	
	
		
		<tr align="left">
		 <td></td>
		 <td colspan="4">
			<input type="submit" name="change_password" value ="Save" style="padding:10px 15px;background:rgba(28,130,199,0.9);border:0.01px solid rgba(28,130,199,0.8);color:white" />
		 </td>
		</tr>
		
	</table>


</form>
</div>


<?php
if(isset($_POST['change_password'])){
	
		$current_password =trim($_POST['current_password']);
		$hash_current_password = md5($current_password);

		$new_password =  trim($_POST['new_password']);
		$hash_new_password = md5($new_password);
		$confirm_new_password = trim($_POST['confirm_new_password']);
		
		$select_password = mysqli_query($con, "select * from users where password='$hash_current_password' and id='$_SESSION[user_id]' ");
		
		//check if current password not empty
		if(mysqli_num_rows($select_password)==0){
			echo "<script>alert('Your current password is wrong!')</script>";
		}elseif($new_password !=$confirm_new_password){
			echo "<script>alert('password do not match!')</script>";
			
		}else{
			$update = mysqli_query($con,"update users set password='$hash_new_password'where id ='$_SESSION[user_id]' ");
			
			if($update){
				echo "<script>alert('Your password was updated successfully!')</script>";
				
				echo"<script>window.open(window.location.href,'_self')</script>";
			}else{
				echo "<script>alert('Database query failed: mysqli_error($con) !')</script>";
			}
		}
}

 ?>