<?php
	$select_user = mysqli_query($con,"select * from users where id='$_SESSION[user_id]' ");
	
	$fetch_user = mysqli_fetch_array($select_user);
?>
		<div class ="register_box" style ="width:100%;float:left;padding:15px;background:white">

		<form method ="post" action ="" enctype= "multipart/form-data">

			<table align="left" width ="70%">
				<tr align="left">
					<td colspan ="4">
					<h2 style="background:rgb(66, 245, 239)">Edit Profile.</h2><br/>
					</td>
				</tr>
				
				<tr>
					<td width="30%"><b>Change Name:</b></td>
					<td colspan="3"><input type ="text" name ="name" value="<?php echo $fetch_user['name'];?>" placeholder ="Name" required style="width:60%;padding:3px ;margin:5px 0"/></td>
				</tr>
		
	
		
		<tr>
		 <td width="15%"><b>Country:</b></td>
		 <td colspan="3">
		 <?php include('users/edit_country_list.php'); ?>
		 </td>
		</tr>
		
		<tr>
		 <td width="15%"><b>City:</b></td>
		 <td colspan="3"><input type ="text" name ="city" value="<?php echo $fetch_user['city'];?>" required placeholder ="City" style="width:60%;padding:3px ;margin:5px 0"/></td>
		</tr>
		
		
		<tr>
		 <td width="15%"><b>Contact:</b></td>
		 <td colspan="3"><input type ="text" name ="contact" value="<?php echo $fetch_user['contact'];?>" required placeholder ="Contact" style="width:60%;padding:3px ;margin:5px 0"/></td>
		</tr>
		
		<tr>
		 <td width="15%"><b>Address:</b></td>
		 <td colspan="3"><input type ="text" name ="address" value="<?php echo $fetch_user['user_address'];?>" required placeholder ="address" style="width:60%;padding:3px ;margin:5px 0"/></td>
		</tr>
		
		<tr align="left">
		 <td></td>
		 <td colspan="4">
			<input type="submit" name="edit_profile" value ="Save" style="padding:10px 15px;background:rgba(28,130,199,0.9);border:0.01px solid rgba(28,130,199,0.8);color:white" />
		 </td>
		</tr>
		
	</table>


</form>
</div>


<?php
if(isset($_POST['edit_profile'])){
	if($_POST['name'] !='' && $_POST['edit_country'] !='' && $_POST['city'] !='' && $_POST['contact']!='' && $_POST['address']!='' ){
		
		$name = $_POST['name'];
		$country = $_POST['edit_country'];
		$city = $_POST['city'];
		$contact = $_POST['contact'];
		$address = $_POST['address'];
		
		
		$update_profile = mysqli_query($con, "update users set name='$name', country='$country',city='$city',contact='$contact',user_address='$address' where id='$_SESSION[user_id]' ");
		
		if($update_profile){
			echo "<script>alert('Your updated was succussfully!')</script>";
			
			echo "<script>window.open(window.location.href,'_self')</script>";
		}
	
	
	}
	
	
}

 ?>