<div id ="footer" style="background:#fofofo">
	<h2 style ="text-align:center; padding-top:30px">&copy;2020-<?php echo date('Y');?> by www.fashionhouse.com</h2>
	</div>
	
</div><!-- /.main_wrapper-->
<!-- End main container starts -->
</body>
</html>