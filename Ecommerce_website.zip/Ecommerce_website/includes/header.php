<?php
session_start();
include("functions/functions.php");
include("includes/db.php");
?>

<!DOCTYPE html>
<html>
<head>
<title>online shopping for dresses</title>
 <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link href="css/bootstrap.css" rel="stylesheet"/>
 
 <link href="styles/desktop.css" type="text/css" rel="stylesheet">
<script src="js/script.js"></script> 
<script src="js/bootstrap.js"></script> 
<script src="js/jquery-1.10.2.js"></script> 
<script src = "../js/jquery.js"></script>

<link rel="stylesheet" href="styles/style.css" media="all" />
<script src = "js/jquery.js"></script>

<style>

.w3-sidebar a {font-family: "Roboto", sans-serif}
body,h1,h2,h3,h4,h5,h6,.w3-wide {font-family: "Montserrat", sans-serif;}
#profile{
	float:right;
	height:35px;
	line-height:35px;
	position:relative;
	margin-top:15px;
	margin-right:30px;
}
#profile img{
	width:45px;
	height:50px;
	position:relative;
	top:-1.8px;
	padding-left:10px;
}
#profile ul{
	list-style:none;
	position:relative;
}
#profile ul a{
	line-height:35px;
	color:black;
	text-decoration:none;
}
#profile ul a:hover{
	text-decoration:underline;
}
#profile ul li ul{
	position:absolute;
	top:40px;
	right:1px;
	white-space:nowrap;
	background:white;
	width:auto;
	z-index:11;
	display:none;
}
#profile ul li ul li a{
	padding:2px 25px 2px 15px;
	
}
	
#form-search input[type=text]{
	border-radius:25px;
}
* {box-sizing: border-box;}


body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
 
}
.topnav .search-container {
  float: right;
   background-color: #e9e9e9;
   margin-top: 8px;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  margin-bottom:8px;
  margin-left:8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 13px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
.topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}

</style>
</head>

<body class="w3-content" style="max-width:1250px">


<!-- Top menu on small screens -->
<header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
  <div class="w3-bar-item w3-padding-24 w3-wide"><a href ="index.php">
				<img id ="logo" src ="images/logo1.jpg" width="150px" height="120px"/>	
				</a></div>
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
<div class="w3-main" style="margin-left:200px">
  <!-- Push down content on small screens -->
  <div class="w3-hide-large" style="margin-top:83px"></div>

<!-- Main container starts -->
<div class ="main_wrapper" style="background:white;width:100%">
<div class="topnav">
<div class="w3-main">
	<header class="w3-container w3-xlarge">
		<p class="w3-right">

	
	<div class="cart"style="float:right">
				<ul>
					<li class="dropdown_header_cart">
					<div id="notification_header_cart" class="shopping-cart" style="margin-right:4px">
						<i class="fa fa-shopping-cart w3-margin-right"></i>
						<div class = "noti_cart_number" style="background:red;color:white;font-size:12px;position:absolute;top:-8px;left:24px;padding:1.5px 2px 1.5px 2px">
							<?php total_items();?>
						</div>
					</div>
					</li>
				</ul>
			</div>
  
	<div class="search-container">
		<form action="results.php">
			<input type="text" placeholder="Search.." name="user_query">
			<button type="submit" name="search"><i class="fa fa-search"></i></button>
		</form>
	</div>
	
			
	<?php if(!isset($_SESSION['user_id'])){ ?>
	<div class="log">
		<div class ="loginbtn" style="display:inline ;padding:2px;margin-left:400px;margin-right:5px"><a style="text-decoration:none;color:#a5a58d" href="index.php?action=login">Login</a></div>
		<div class="registerbtn" style="display:inline;padding:2px;margin-left:10px;margin-right:5px"><a style="text-decoration:none;color:#a5a58d" href="register.php" style="color:white;">Sign Up</a></div>
	</div>
	</p>
	</header>
	</div>
	<div class="header_wrapper">
	

	<?php }else{?>
	
	<?php 
	$select_user = mysqli_query($con ,"select * from users where id='$_SESSION[user_id]' ");
	$data_user = mysqli_fetch_array($select_user);
	
	?>
	
	<div id="profile">
		<ul>
			<li class ="dropdown_header">
			 <a>
			 <?php if($data_user['image'] !=''){ ?>
			  <span><img src ="upload-files/<?php echo $data_user['image'];?>"></span> 
			 <?php }else{ ?>
			  <span><img src ="images/download (4).jpg"></span>
			 
			 <?php } ?>
			 
			 </a>
			 
			 <ul class="dropdown_menu_header">
				<li><a href="my_account.php?action=edit_account">Account Setting</a></li>
				<li><a href="logout.php">Logout</a></li>
			 
			 </ul>
			</li>
		</ul>
	</div>
	
	<?php } ?>
	
	</div><!-- /.header_wrapper-->
	
	<!-- Hidden Sidebar (reveals when clicked on menu icon)-->
<nav class="w3-sidebar w3-black w3-animate-right w3-xxlarge" style="display:none;padding-top:150px;right:0;z-index:2" id="mySidebar">
  <a href="javascript:void(0)" onclick="closeNav()" class="w3-button w3-black w3-xxxlarge w3-display-topright" style="padding:0 12px">
    <i class="fa fa-remove"></i>
  </a>
  <div class="w3-bar-block w3-center">
    <a href="index.php" class="w3-bar-item w3-button w3-text-grey w3-hover-black" onclick="closeNav()">Home</a>
    <a href="all_products.php" class="w3-bar-item w3-button w3-text-grey w3-hover-black" onclick="closeNav()">All products</a>
    <a href="my_account.php" class="w3-bar-item w3-button w3-text-grey w3-hover-black" onclick="closeNav()">My Account</a>
    <a href="cart.php" class="w3-bar-item w3-button w3-text-grey w3-hover-black" onclick="closeNav()">Shopping cart</a>
    <a href="contact.php" class="w3-bar-item w3-button w3-text-grey w3-hover-black" onclick="closeNav()">Contact Us</a>
    <a href="logout.php" class="w3-bar-item w3-button w3-text-grey w3-hover-black" onclick="closeNav()">Logout</a>
  </div>
</nav>



  <!-- Menu icon to open sidebar -->
<span class="w3-button w3-top w3-white w3-xxlarge w3-text-grey w3-hover-text-black" style="width:auto;right:0;" onclick="openNav()"><i class="fa fa-bars"></i></span>


  
 
<!-- END PAGE CONTENT -->
</div>

<script>
// Open and close sidebar
function openNav() {
  document.getElementById("mySidebar").style.width = "60%";
  document.getElementById("mySidebar").style.display = "block";
}

function closeNav() {
  document.getElementById("mySidebar").style.display = "none";
}
</script>
	</div>
	</div>
		
    <?php include('js/drop_down_menu.php'); ?>