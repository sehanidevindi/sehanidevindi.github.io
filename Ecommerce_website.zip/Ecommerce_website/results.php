<?php
include("includes/header.php");

?>
	
	
	<div class="content_wrapper">
	<nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top" style="z-index:3;width:250px" id="mySidebar">
	<div class="w3-container w3-display-container w3-padding-16">
    <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
	</div>
		<div id="sidebar" style="float:left; background-color:DDBEA9">
			<div class = "header_logo">
				<a href ="index.php">
				<img id ="logo" src ="images/fashion_house.jpg" width="77%" height="66%"/>	
				</a>
			</div><!--/.header_logo-->
			<div id="sidebar_title">Categories</div>
			<ul id="cats">
				
				<?php
				getCats();
				?>
			</ul>
			
			<div id="sidebar_title">Brands</div>
			<ul id="cats">
				<?php
				getBrands();
				?>
		
			</ul>
		</div><!--/#sidebar -->
		
		</nav>	
		<div class="w3-main" style="margin-left:250px;margin-right:5px">
			
			<div id="products_box" class="w3-row w3-grayscale-min" >
			
				<?php
				 if(isset($_GET['search'])){
					$search_query = $_GET['user_query'];
					$run_query_by_pro_id = mysqli_query($con, "select * from products where product_keywords like '%$search_query%' ");
						while($row_pro = mysqli_fetch_array($run_query_by_pro_id)){
						$pro_id = $row_pro['product_id'];
						$pro_cat = $row_pro['product_cat'];
						$pro_brand = $row_pro['product_brand'];
						$pro_title = $row_pro['product_title'];
						$pro_price = $row_pro['product_price'];
						$pro_image = $row_pro['product_image'];
						
							
						echo "
							
							<div class ='w3-col l3 s6'>
								<div class='w3-container'>
								   <div class='w3-display-container' style='padding:15px;float:left'>
										<img src = 'admin_area/product_images/$pro_image' width='160' height='180'style='border:none'/>
										<div class='w3-display-middle w3-display-hover'>
											<div class='buttons'>
											<a href='index.php?add_cart=$pro_id'><button class='w3-button w3-black' >Buy now <i class='fa fa-shopping-cart'></i></button></a>
											</div>
										</div>
										<p>$pro_title </br><b> Price: Rs. $pro_price </b></p>
									</div>
								</div>
								
							</div>
						";
					 }
				 }
				 
				?>
				
				<?php
					get_pro_by_cat_id();
				?>
				
				<?php
					get_pro_by_brand_id();
				?>
				
				
			</div><!-- /#products_box-->
		</div>
		
	</div><!-- /.content_wrapper-->
	
	<?php include ('includes/footer.php');?>
